export const HeroSection = () => {
  return <div>Hero Section</div>;
};
