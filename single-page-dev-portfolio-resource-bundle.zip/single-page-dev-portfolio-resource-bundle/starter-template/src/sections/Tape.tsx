export const TapeSection = () => {
  return <div>Tape Section</div>;
};
