export const AboutSection = () => {
  return <div>About Section</div>;
};
