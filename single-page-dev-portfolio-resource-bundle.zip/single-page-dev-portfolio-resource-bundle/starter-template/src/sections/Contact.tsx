export const ContactSection = () => {
  return <div>Contact Section</div>;
};
