export const Footer = () => {
  return <div>Footer Section</div>;
};
