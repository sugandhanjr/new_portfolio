export const Header = () => {
  return <div>Header Section</div>;
};
